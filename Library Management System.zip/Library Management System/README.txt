PROJECT NAME : LIBRARY MANAGEMENT SYSTEM
Language     : Java [JDK-15.0.2]

Steps to follow :
- Your system must have Java installed
- Run the Main.java file using these commands
    javac Main.java
    java Main
- Explore the project